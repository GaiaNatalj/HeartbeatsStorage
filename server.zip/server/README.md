ipconfig

 Indirizzo IPv4. . . . . . . . . . . . : 192.168.1.120


 node server.js

 http://192.168.1.120:80/heartbeat?bpm=60&bps=1

 verifica server: curl "http://localhost:80/heartbeat?bpm=72&bps=1.2"
                  curl "http://192.168.56.1:300/heartbeat?bpm=72&bps=1.2"
                  curl "http://169.254.68.137:300/heartbeat?bpm=72&bps=1.2"
                  b