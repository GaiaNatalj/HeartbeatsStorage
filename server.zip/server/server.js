const express = require('express');
const os = require('os');
const cors = require('cors');


const app = express();
const PORT = 3000;

let bpmValues = []; 
let bpsValues = []; 

app.use(express.json());
app.use(cors());

app.get('/heartbeat', (req, res) => {
    const { bpm, bps } = req.query;
    console.log(`Received heartbeat data - BPM: ${bpm}, BPS: ${bps}`);
    // Aggiorna le liste con i nuovi valori
    bpmValues.push(Number(bpm));
    bpsValues.push(Number(bps));

    res.sendStatus(200);
});

// Endpoint per permettere al client di recuperare i dati
app.get('/getData', (req, res) => {
    const oraCorrente = date();
     // Mantieni solo gli ultimi 5 valori
     if (bpmValues.length > 5) bpmValues.shift();
     if (bpsValues.length > 5) bpsValues.shift();
     const avgBpm = bpmValues.reduce((sum, val) => sum + val, 0) / bpmValues.length;
     const avgBps = bpsValues.reduce((sum, val) => sum + val, 0) / bpsValues.length;
 
     const data = { 
         bpm: avgBpm.toFixed(2), 
         bps: avgBps.toFixed(2), 
         timestamp: oraCorrente 
     };
     
    res.json(data); 
    
});

app.listen(PORT, () => {
    const networkInterfaces = os.networkInterfaces();
    for (const interfaceName in networkInterfaces) {
        networkInterfaces[interfaceName].forEach((interface) => {
            if (interface.family === 'IPv4' && !interface.internal) {
                console.log(`Server is running on http://${interface.address}:${PORT}`);
            }
        });
    }
});

const date = () => {
    var dataOdierna = new Date();
    var ora = dataOdierna.getHours();
    var minuti = dataOdierna.getMinutes();
    var secondi = dataOdierna.getSeconds();
    var oraCorrente =
      ora +
      ":" +
      (minuti < 10 ? "0" : "") +
      minuti +
      ":" +
      (secondi < 10 ? "0" : "") +
      secondi;
    return oraCorrente;
  };

